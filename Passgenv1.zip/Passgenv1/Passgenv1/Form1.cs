﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Passgenv1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                PassGenerator(8);
            }
            else if (checkBox2.Checked)
            {
                PassGenerator(10);
            }
            else if (checkBox3.Checked)
            {
                PassGenerator(12);
            }
            else
            {
                PassGenerator(8);
            }
        }
        public void PassGenerator(int len)
        {
            const string ValidChar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ12345678910!@#$%^&*()[]";
            StringBuilder result = new StringBuilder();
            Random rand = new Random();


            for (int i = 0; i < len; i++)
            {
                result.Append(ValidChar[rand.Next(ValidChar.Length)]);

            }
            textBox1.Text = result.ToString();
        }
    }
}
