﻿namespace PasswordGeneratorApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.rbLength8 = new System.Windows.Forms.RadioButton();
            this.rbLength12 = new System.Windows.Forms.RadioButton();
            this.rbLength24 = new System.Windows.Forms.RadioButton();
            this.cbUppercase = new System.Windows.Forms.CheckBox();
            this.cbSpecialChars = new System.Windows.Forms.CheckBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(12, 12);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.ReadOnly = true;
            this.txtPassword.Size = new System.Drawing.Size(300, 20);
            this.txtPassword.TabIndex = 0;
            // 
            // rbLength8
            // 
            this.rbLength8.AutoSize = true;
            this.rbLength8.Checked = true;
            this.rbLength8.Location = new System.Drawing.Point(12, 38);
            this.rbLength8.Name = "rbLength8";
            this.rbLength8.Size = new System.Drawing.Size(43, 17);
            this.rbLength8.TabIndex = 1;
            this.rbLength8.TabStop = true;
            this.rbLength8.Text = "8";
            this.rbLength8.UseVisualStyleBackColor = true;
            // 
            // rbLength12
            // 
            this.rbLength12.AutoSize = true;
            this.rbLength12.Location = new System.Drawing.Point(61, 38);
            this.rbLength12.Name = "rbLength12";
            this.rbLength12.Size = new System.Drawing.Size(49, 17);
            this.rbLength12.TabIndex = 2;
            this.rbLength12.Text = "12";
            this.rbLength12.UseVisualStyleBackColor = true;
            // 
            // rbLength24
            // 
            this.rbLength24.AutoSize = true;
            this.rbLength24.Location = new System.Drawing.Point(116, 38);
            this.rbLength24.Name = "rbLength24";
            this.rbLength24.Size = new System.Drawing.Size(49, 17);
            this.rbLength24.TabIndex = 3;
            this.rbLength24.Text = "24";
            this.rbLength24.UseVisualStyleBackColor = true;
            // 
            // cbUppercase
            // 
            this.cbUppercase.AutoSize = true;
            this.cbUppercase.Location = new System.Drawing.Point(12, 61);
            this.cbUppercase.Name = "cbUppercase";
            this.cbUppercase.Size = new System.Drawing.Size(100, 17);
            this.cbUppercase.TabIndex = 4;
            this.cbUppercase.Text = "Буквы";
            this.cbUppercase.UseVisualStyleBackColor = true;
            // 
            // cbSpecialChars
            // 
            this.cbSpecialChars.AutoSize = true;
            this.cbSpecialChars.Location = new System.Drawing.Point(12, 84);
            this.cbSpecialChars.Name = "cbSpecialChars";
            this.cbSpecialChars.Size = new System.Drawing.Size(110, 17);
            this.cbSpecialChars.TabIndex = 5;
            this.cbSpecialChars.Text = "Спецсимволы";
            this.cbSpecialChars.UseVisualStyleBackColor = true;
            // 
            // btnGenerate
            // 
            this.btnGenerate.Location = new System.Drawing.Point(12, 107);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(100, 23);
            this.btnGenerate.TabIndex = 6;
            this.btnGenerate.Text = "Сгенерировать";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(324, 142);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.cbSpecialChars);
            this.Controls.Add(this.cbUppercase);
            this.Controls.Add(this.rbLength24);
            this.Controls.Add(this.rbLength12);
            this.Controls.Add(this.rbLength8);
            this.Controls.Add(this.txtPassword);
            this.Name = "Form1";
            this.Text = "Генератор паролей";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.RadioButton rbLength8;
        private System.Windows.Forms.RadioButton rbLength12;
        private System.Windows.Forms.RadioButton rbLength24;
        private System.Windows.Forms.CheckBox cbUppercase;
        private System.Windows.Forms.CheckBox cbSpecialChars;
        private System.Windows.Forms.Button btnGenerate;
    }
}
