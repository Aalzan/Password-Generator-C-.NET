﻿using System;
using System.Windows.Forms;

namespace PasswordGeneratorApp
{

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    public partial class Form1 : Form
    {
        private const string UppercaseChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        private const string NumericChars = "0123456789";
        private const string SpecialChars = "!@#$%^&*()_-+=<>?";

        private readonly Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            int passwordLength = GetSelectedPasswordLength();
            string characters = GetSelectedCharacters();

            string password = GeneratePassword(passwordLength, characters);
            txtPassword.Text = password;
        }

        private int GetSelectedPasswordLength()
        {
            if (rbLength8.Checked)
                return 8;
            else if (rbLength12.Checked)
                return 12;
            else if (rbLength24.Checked)
                return 24;
            else
                return 8; 
        }

        private string GetSelectedCharacters()
        {
            string characters = NumericChars;

            if (cbUppercase.Checked)
                characters += UppercaseChars;

            if (cbSpecialChars.Checked)
                characters += SpecialChars;

            return characters;
        }

        private string GeneratePassword(int length, string characters)
        {
            char[] password = new char[length];
            for (int i = 0; i < length; i++)
            {
                password[i] = characters[random.Next(characters.Length)];
            }

            return new string(password);
        }
    }
}
